#include "stdafx.h"
 #include<stdio.h>
#include <iostream> 
#include "curl/curl.h" 
 #include <string>

typedef struct downfile {
	int  len;
	char * buffer;
	FILE *fp;
}DownFile;

#pragma comment( lib,"libcurl_imp.lib" ) 
#define MAXHTML_SIZE 20480
using namespace std;
FILE *fp,*fp_jpg ;

typedef   size_t  (* DownLoadWriteCallBack)(void *, size_t , size_t , void *)  ;

BOOL PostData (CURL * curl,const char* url,const char * postdata, const char * cookie ,  DownLoadWriteCallBack ,void*databack );

 

BOOL StartLogin (CURL * curl,const char* url,char * Cookie, char* postinfo );


BOOL down_yanzhengma (CURL * curl,const char* url, char * cookie , DownLoadWriteCallBack  handle_html_p );

string g_webhtml = "";
string g_session = "";
string g_otn = "";
string g_outcookie = "";
int	 g_openhead = 0,g_openzip=0,g_savecookie=0;

int HTML_SIZE = 0;

size_t handle_html (void * ptr, size_t size, size_t nmemb , void * stream) 
{
       g_webhtml.append((char*)ptr);

        return size*nmemb;
}

size_t handle_login (void * ptr, size_t size, size_t nmemb , void * stream) 
{
	g_webhtml.append((char*)ptr);
	 fwrite(ptr,size,nmemb ,(FILE*)stream);
	return size*nmemb;
}

int time_s = 0;
int filesize_jpg=0,write_size =0;
size_t save_yanzhengma (void * ptr, size_t size, size_t nmemb , void * stream) 
{
    DownFile   *df = (DownFile*)stream;
	//write_size+=fwrite(ptr ,size,nmemb,df->fp);
	memcpy(&(df->buffer[df->len]),ptr,size*nmemb);
	df->len+=size *nmemb;

	return size *nmemb;
}



int GetCookie ();


int _tmain (int argc, _TCHAR * argv[])
{
         CURL *curl ;
         CURLcode res ;
        
		 DownFile   df;
		 df.buffer = new char[MAXHTML_SIZE];
		 df.len = 0;
		 
         int start =  GetTickCount();
         cout<<" ��ʼ��ʼ�� curl"<<endl ;
         curl = curl_easy_init ();
         if( !curl ) {
                 cout<<"curl ��ʼ��ʧ�� "<<endl ;

        }


		 
         g_openhead = 0;
         cout<<"curl ��ʼ���ɹ� "<<endl ;
		 char File_url[256]="https://kyfw.12306.cn/otn/passcodeNew/getPassCodeNew?module=passenger&amp;rand=randp";
		 while(1){

			 g_webhtml.clear();
			 filesize_jpg=0,write_size =0;
			 memset(df.buffer,0,MAXHTML_SIZE);
			 df.len = 0;
			 if((fp =fopen( "baidu.txt","w" ))==NULL)
			 {
				 curl_easy_cleanup(curl );
				 exit(1);
			 }
			 if(( df.fp =fopen( "��֤��.jpg","wb" ))==NULL)
			 {
				 curl_easy_cleanup(curl );
				 exit(1);

			 }
			 g_savecookie = 1;
			 g_openhead = 1;
			 g_openzip = 1;
			 //��½ҳ���ȡsession��������֤��
			 PostData(curl
					, "https://kyfw.12306.cn/otn/login/init"
					, NULL
					, "",handle_html ,NULL);

			 fwrite(g_webhtml.c_str(),1,g_webhtml.length(),fp);
			g_openhead = 0;
			g_openzip = 0;
			 g_savecookie = 0;

			// GetCookie();
			randcode:
			 cout<<" ===========������֤��===========" <<endl;
			
			 //������֤��
			 PostData(curl
				 ,"https://kyfw.12306.cn/otn/passcodeNew/getPassCodeNew?module=login&rand=sjrand"
				 ,NULL
				 ,"", save_yanzhengma ,(char*)&df);
				
			 int ret = fwrite(df.buffer,1,df.len,df.fp);

				fclose(fp);
				
				fclose(df.fp);
	         
			g_webhtml.clear();

			cout<<"������֤��:"<<endl;

			string username,passwd,code;
			username="lilien1010";
			passwd="qq331838389";
			cin>>code;
		
			
			string rand_code = ""; 
			FILE * randfp = fopen("��֤�뷵��.txt","w");
			rand_code.append("randCode=");
			rand_code.append(code);
			rand_code.append("&rand=sjrand");
			//�����֤�� 
			PostData(curl
				,"https://kyfw.12306.cn/otn/passcodeNew/checkRandCodeAnsyn"
				,rand_code.c_str()
				,NULL
				, handle_login ,(char*)randfp); 

			cout<<"��֤����------------ "<<g_webhtml<<endl;
			if(g_webhtml.find("data: \"Y\"")>0)
			{
					cout<<"------------��֤��ɹ�------------"<<endl;
			}else{
					cout<<"------------��֤����ʧ��------------"<<endl;
					goto  randcode;
			}

			fclose(randfp);


			g_webhtml.clear();
			cout<<"��������� username= "<<username<<" passwd= "<<passwd<<" code= "<<code<<endl;
			string post_data="";
			post_data.append("loginUserDTO.user_name=");
			post_data.append(username);
			post_data.append("&userDTO.password=");
			post_data.append(passwd);
			post_data.append("&randCode=");
			post_data.append(code); 
			FILE * logfp = fopen("��¼����.txt","w");
			//��¼
			PostData(curl
					,"https://kyfw.12306.cn/otn/login/loginAysnSuggest"
					,post_data.c_str()
					,NULL
					, handle_login ,logfp);  
			cout<<" ��¼���------------ "<<endl;
			if(g_webhtml.find("\"loginCheck\":\"Y\"")>0)
			{
				cout<<"------------��¼�ɹ�------------"<<endl;
			}else{
				cout<<"------------��¼�ɹ�ʧ��------------"<<g_webhtml<<endl;
				goto  randcode;
			}


			fclose(logfp);
			
			g_webhtml.clear();

			FILE * userfp = fopen("��ȡ������Ϣ.txt","w");

			//��ȡ������Ϣ
			PostData(curl
					,"https://kyfw.12306.cn/otn/confirmPassenger/getPassengerDTOs"
					,NULL
					,NULL
					, handle_login ,userfp);  
			cout<<" ��ȡ������Ϣ------------ "<<g_webhtml<<endl;

			if(g_webhtml.find("\"isExist\":true")>0)
			{
				cout<<"------------��ȡ�ɹ�------------"<<endl;
			}else{
				cout<<"------------��ȡ�ɹ�ʧ��------------"<<endl; 
			}
			fclose(userfp);
  
			cout<<" the cookie is=\"" << g_outcookie. c_str()<<"\"" <<endl;

			 cout<<"time span = " << GetTickCount() - start<<endl ;


			 cout<<"filesize_jpg  =  " << filesize_jpg<<"write_size="<<write_size<<" df->len "<<df.len<<endl ;

			 string in="";
				cin>>in;
			 if( in[0] == 'q'){
				 break;
			 }

			 if(in[0] =='c'){

				 strcpy(File_url,&in[1]);
			 }

			 if( in[0] == 'o')
				 g_openhead = 1;
			 else
				g_openhead = 0;

			 if( in[0] == 'z')
				 g_openzip = 1;
			 else 
				 g_openzip = 0;

			 cout<<" input code  = "<<in<<endl; 
		 }
		 curl_easy_cleanup(curl );
         return 0;
}


BOOL PostData (CURL * curl,const char* url,const char * postdata, const char * cookie , DownLoadWriteCallBack  handle_html_p ,void*databack  ){

         CURLcode res ;
			g_webhtml	="";
         curl_easy_setopt( curl , CURLOPT_URL, url);

         curl_easy_setopt(curl , CURLOPT_SSL_VERIFYPEER, 0L);     
        
         curl_slist *http_headers = NULL;

 
         http_headers = curl_slist_append (http_headers, "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
         http_headers = curl_slist_append (http_headers, "Accept-Encoding: gzip,deflate,sdch" );
         http_headers = curl_slist_append (http_headers, "Accept-Language: zh-CN,zh;q=0.8" );
         http_headers = curl_slist_append (http_headers, "Accept-Charset: GBK,utf-8;q=0.7,*;q=0.3");
         http_headers = curl_slist_append (http_headers, "Host: kyfw.12306.cn" );
         http_headers = curl_slist_append (http_headers, "Connection: keep-alive" );
         http_headers = curl_slist_append (http_headers, "Referer: https://kyfw.12306.cn/otn/login/init");

		 if(g_savecookie)
				curl_easy_setopt(curl, CURLOPT_COOKIEJAR, "C:\\cookie.txt");
		 else
			curl_easy_setopt(curl, CURLOPT_COOKIEFILE, "C:\\cookie.txt");

	     curl_easy_setopt(curl , CURLOPT_VERBOSE, 1L);

         curl_easy_setopt(curl , CURLOPT_HTTPHEADER, http_headers);
         curl_easy_setopt(curl , CURLOPT_HEADER, g_openhead);                                       // ��ʾ���ص�Header��������
         curl_easy_setopt(curl , CURLOPT_SSL_VERIFYPEER, 0L);
         curl_easy_setopt(curl , CURLOPT_SSL_VERIFYHOST, 0L);
         curl_easy_setopt(curl , CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1");
		if(g_openzip)	curl_easy_setopt(curl , CURLOPT_ENCODING, "gzip");

         if(postdata ){
                 curl_easy_setopt(curl , CURLOPT_POSTFIELDS, postdata);
        }

         if(cookie ){
                 curl_easy_setopt(curl , CURLOPT_COOKIE, cookie);
        }
        
		 if(databack){
				 curl_easy_setopt(curl , CURLOPT_WRITEDATA, databack); 
		 }
		 if(handle_html_p){
				 curl_easy_setopt(curl , CURLOPT_WRITEFUNCTION, handle_html_p); 
		}
         res = curl_easy_perform ( curl );
         long code ; 
 
         curl_easy_getinfo(curl ,CURLINFO_RESPONSE_CODE, & code); 
         curl_slist_free_all(http_headers );

         //fwrite(szbuffer ,1,strlen( szbuffer),fp );
         if(CURLE_OK !=res)
                 return FALSE ;
 
         return TRUE ;    
}






int GetCookie (){
         string Cookiestr = "Set-Cookie: ";
		 string end_cookie	= "; ";
		 int	len_cookiestr = Cookiestr.length (); 
		 int id1 =0 , id2 = 0;
		 g_outcookie="";
		 while(1){
         id1   = g_webhtml. find(Cookiestr,id2);
         if(id1 < 0 ) break;

          id2   = g_webhtml. find(end_cookie ,id1+ len_cookiestr+1);
         if(id2 < 0 ) break;

         g_session = g_webhtml .substr( id1+len_cookiestr, id2-id1 -len_cookiestr);
 
         g_outcookie.append (g_session);
		 g_outcookie.append ("; ");

		 }

		 return 0;
}


 


// 
// 
// int httpgzdecompress (Byte * zdata, uLong nzdata, Byte *data , uLong * ndata)
// {
//          int err = 0;
//          z_stream d_stream = {0}; /* decompression stream */
//          static char dummy_head[2] =
//         {
//                 0x8 + 0x7 * 0x10,
//                 (((0x8 + 0x7 * 0x10) * 0x100 + 30) / 31 * 31) & 0xFF,
//         };
//          d_stream.zalloc = (alloc_func)0;
//          d_stream.zfree = (free_func)0;
//          d_stream.opaque = (voidpf)0;
//          d_stream.next_in = zdata;
//          d_stream.avail_in = 0;
//          d_stream.next_out = data;
//          if(inflateInit2 (&d_stream, 47) != Z_OK) return -1;
//          while (d_stream .total_out < * ndata && d_stream .total_in < nzdata)
//         {
//                  d_stream.avail_in = d_stream. avail_out = 1; /* force small buffers */
//                  if((err = inflate(& d_stream, Z_NO_FLUSH )) == Z_STREAM_END) break;
//                  if(err != Z_OK )
//                 {
//                          if(err == Z_DATA_ERROR)
//                         {
//                                  d_stream.next_in = (Bytef*) dummy_head;
//                                  d_stream.avail_in = sizeof( dummy_head);
//                                  if((err = inflate(& d_stream, Z_NO_FLUSH )) != Z_OK)
//                                 {
//                                          return -1;
//                                 }
//                         }
//                          else return -1;
//                 }
//         }
//          if(inflateEnd (&d_stream) != Z_OK) return -1;
//         * ndata = d_stream .total_out;
//          return 0;
// }






 