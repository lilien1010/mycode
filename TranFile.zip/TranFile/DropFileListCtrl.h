#pragma once


// CDropFileListCtrl

class CDropFileListCtrl : public CListCtrl
{
	DECLARE_DYNAMIC(CDropFileListCtrl)

public:
	CDropFileListCtrl();
	virtual ~CDropFileListCtrl();

protected:

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnDropFiles(HDROP hDropInfo);
};


