function bianliios()
   local file = io.open(infilename, "r");
   if(file) then

	   for qq in file:lines()   do
	   dealline(qq)
	   end

	   file:close();
	else
		print("get file wrong");

   end
end


function dealline(str)

	if(string.len(str)==0) then
		--	��ǰΪ����
		--print("get file wrong");
	else

		if(nil~=string.find(str, "/\*[\s\w]*\*/")) then
		--	��ǰΪע����
			  --print(str);
			 str = changeNote(str);
		elseif(nil~=string.find(str, '".*"%s*=%s*".*"')) then
		--	��ǰΪ��ֵ��
				--print(str);
				str = changeKey(str);

				--print(sss);
		end

   end

   fileout:write(str.."\n");

end


--�޸�key��
function changeKey(str)

    --local id = string.find(str,'%s*=%s*');

	--str=  string.gsub(str, "&", "");
	t = {} ;
	for k, v in string.gmatch(str,'"(.*)"%s*=%s*"(.*)"') do
	t[k]=v;
	end
	local kk,vv;
	for k, v in pairs(t) do
	kk=k;
	vv=v;
	end

	kk=  string.gsub(kk, "%s", "_");
	kk=  string.gsub(kk, "-", "_");
	kk=  string.gsub(kk, "\+", "");
	kk=  string.gsub(kk, "\?", "");
	kk=  string.gsub(kk, "%.", "");
	kk=  string.gsub(kk, ",", "");
	kk=  string.gsub(kk, "&", "");
	kk=  string.gsub(kk, "%(", "");
	kk=  string.gsub(kk, "%)", "");
	kk=  string.gsub(kk, "%[", "");
	kk=  string.gsub(kk, "%]", "");
	kk=  string.gsub(kk, "'", "");
	kk=  string.gsub(kk, "%%\@", "s");
	kk=  string.gsub(kk, "%%(%d)\$@", "%1s");
	kk = string.lower(kk);

	vv=  string.gsub(vv, "%%@", "%%s");
	vv=  string.gsub(vv,"%$@","$s");


	return '<string name="'..kk..'">'..vv..'</string>';
end

--�޸�ע��
function changeNote(str)

	str=  string.gsub(str, "/%*", "<!--");
	str=  string.gsub(str, "%*/", "-->");

   return str;
end


fileout = io.open(outfilename, "w");
if(fileout) then
bianliios();
end
fileout:close();
