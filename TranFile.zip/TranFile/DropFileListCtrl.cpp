// DropFileListCtrl.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "TranFile.h"
#include "DropFileListCtrl.h"


// CDropFileListCtrl

IMPLEMENT_DYNAMIC(CDropFileListCtrl, CListCtrl)

CDropFileListCtrl::CDropFileListCtrl()
{

}

CDropFileListCtrl::~CDropFileListCtrl()
{
}


BEGIN_MESSAGE_MAP(CDropFileListCtrl, CListCtrl)
	ON_WM_DROPFILES()
END_MESSAGE_MAP()



// CDropFileListCtrl ��Ϣ��������



void CDropFileListCtrl::OnDropFiles(HDROP hDropInfo)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	WCHAR filePath[MAX_PATH];
	WIN32_FIND_DATA wfd;

	CString strFileName;
	CString strFileSize;
	CString strCreateTime;
	 
	int nCounts = DragQueryFile(hDropInfo, 0xFFFFFFFF, NULL, 0);		//��ȡ��ק�����ļ���
	for (int i = 0; i < nCounts; i++)
	{
		DragQueryFile(hDropInfo, i, filePath, sizeof(filePath)*2);
		FindClose(FindFirstFile(filePath, &wfd));

		strFileName = wfd.cFileName;
		strFileSize.Format(_T("%d"), wfd.nFileSizeLow);
		CTime time(wfd.ftCreationTime);
		strCreateTime = time.Format(_T("%Y-%m-%d %H:%M:%S"));

		InsertItem(i,filePath);
		SetItemText(i, 1, strFileSize);
		SetItemText(i, 2, strCreateTime);
	}

	CListCtrl::OnDropFiles(hDropInfo);
}
