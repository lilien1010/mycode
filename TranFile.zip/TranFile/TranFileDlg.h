// TranFileDlg.h : ͷ�ļ�
//

#pragma once

extern "C" {  
#include "lua.h"
#include "lualib.h"
#include "lauxlib.h"
}

#include "DropFileListCtrl.h"
#include "afxcmn.h"
// CTranFileDlg �Ի���
class CTranFileDlg : public CDialog
{
// ����
public:
	CTranFileDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_TRANFILE_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��
	CDropFileListCtrl m_DropFileListCtrl;
	lua_State *L;
// ʵ��
protected:
	HICON m_hIcon;
	void Addinfo(CString);
	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	int TransFile(const char * infilename,char*outfilename);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonStartTrans();
public:
	afx_msg void OnLbnSelchangeList1();
public:
	afx_msg void OnBnClickedButtonClean();
};
